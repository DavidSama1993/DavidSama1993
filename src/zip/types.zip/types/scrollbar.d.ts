import { ElementUIComponent } from 'element-ui/types/component'

/** Scrollbar Component */
export declare class ElScrollbar extends ElementUIComponent {
  native: boolean;
  wrapStyle: string | { [PropName: string]: string } | { [PropName: string]: string }[];
  wrapClass: string;
  viewClass: string;
  viewStyle: string | { [PropName: string]: string } | { [PropName: string]: string }[];
  noresize: boolean; // 如果 container 尺寸不会发生变化，最好设置它可以优化性能
  tag: string;
}
